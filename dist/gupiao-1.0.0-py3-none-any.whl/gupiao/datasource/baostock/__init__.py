"""
Baostock 数据源实现

提供基于 baostock 的股票数据源实现
"""

from .datasource import BaostockDataSource

__all__ = ['BaostockDataSource']